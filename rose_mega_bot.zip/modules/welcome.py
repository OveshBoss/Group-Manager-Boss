from pyrogram import filters
from bot import app

@app.on_message(filters.new_chat_members)
async def welcome(_, m):
    for u in m.new_chat_members:
        await m.reply(f"welcome {u.mention}")
