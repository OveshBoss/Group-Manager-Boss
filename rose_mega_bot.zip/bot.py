from pyrogram import Client, filters
from config import *

app = Client(
    "rose_mega",
    api_id=API_ID,
    api_hash=API_HASH,
    bot_token=BOT_TOKEN
)

import modules.bans
import modules.fsub
import modules.welcome

@app.on_message(filters.command("start"))
async def start(_, m):
    await m.reply("ʜᴇʏ 👋 ʀᴏꜱᴇ ꜱᴛʏʟᴇ ᴍᴇɢᴀ ʙᴏᴛ")

app.run()
