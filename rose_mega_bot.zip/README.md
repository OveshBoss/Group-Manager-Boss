# rose style mega bot (merged)
full expandable base