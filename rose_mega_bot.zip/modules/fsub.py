from pyrogram import filters
from bot import app

@app.on_message(filters.command("set_fsub") & filters.admin)
async def fsub(_, m):
    pass
